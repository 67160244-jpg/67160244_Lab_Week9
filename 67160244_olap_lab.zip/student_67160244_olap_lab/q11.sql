SELECT 'before_join' AS stage, COUNT(*) AS n_rows,
       SUM(quantity * unit_price) AS revenue
FROM fact_sales
UNION ALL
SELECT 'after_join', COUNT(*), SUM(amount)
FROM sales;