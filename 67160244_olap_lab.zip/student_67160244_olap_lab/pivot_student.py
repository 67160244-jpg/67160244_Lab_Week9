from pathlib import Path
import sqlite3
import pandas as pd
ROOT=Path(__file__).resolve().parent
with sqlite3.connect((ROOT/'data'/'warehouse.db').as_uri()+'?mode=ro',uri=True) as con:
    df=pd.read_sql_query('SELECT * FROM sales',con)
print(df.head())
# --- P1: province x month ---
p1 = pd.pivot_table(df, index='province', columns='month',
                    values='amount', aggfunc='sum',
                    fill_value=0, margins=True, margins_name='Total')
print(p1)
p1.to_csv(ROOT / 'pivot_province_month.csv', encoding='utf-8-sig')

# --- P2: เฉพาะกันยายน, category x province ---
sep = df[df['month'] == '2026-09']
p2 = pd.pivot_table(sep, index='category', columns='province',
                    values='amount', aggfunc='sum', fill_value=0)
print(p2)
p2.to_csv(ROOT / 'pivot_september.csv', encoding='utf-8-sig')

# --- P3: assert เฉพาะเซลล์ Total x Total ---
grand = p1.loc['Total', 'Total']
assert grand == df['amount'].sum(), f'{grand} != {df["amount"].sum()}'
print('assert OK:', grand)

drink = pd.pivot_table(df[df['category']=='Drink'], index='province',
                       columns='month', values='amount', aggfunc='sum',
                       fill_value=0, margins=True, margins_name='Total')
print(drink)