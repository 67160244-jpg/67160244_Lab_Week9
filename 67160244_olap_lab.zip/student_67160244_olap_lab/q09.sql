SELECT month AS period, SUM(amount) AS revenue
FROM sales
GROUP BY month
UNION ALL
SELECT 'ALL' AS period, SUM(amount) AS revenue
FROM sales;